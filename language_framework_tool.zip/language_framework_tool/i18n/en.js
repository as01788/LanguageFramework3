module.exports = {
    'open': 'Open',
    "replace":"Replace"
  };