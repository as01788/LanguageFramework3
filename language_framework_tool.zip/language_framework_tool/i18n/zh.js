module.exports = {
    'open': '打开',
    "replace":"替换"
  };