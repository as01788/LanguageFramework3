'use strict';
const fs = require("fs");

const outPath = Editor.Project.path + "/assets/LanguageFramework_outs";

//扩展内定义的方法
exports.methods = {
    async createJson() {
        if (!fs.existsSync(outPath)) {
            fs.mkdir(outPath, err => {
                if (err) {
                    console.log("err:" + err);
                    throw err;
                }
            });
        }
        const type = Editor.Selection.getLastSelectedType();
        if (type && type === "node") {
            const uuid = Editor.Selection.getLastSelected(type);
            const node = await getNode(uuid);
            if (node) {
                const data = {UICompontents: []};
                const tempData = {UICompontents: []};
                //先获取自身的sprite组件
                const parentSprite = await getComponent(node, "cc.Sprite");
                if (parentSprite) {
                    const t = await getCompontentsObject("this", parentSprite);
                    t && data.UICompontents.push(t);
                    const temp = await getCompontentsObject("this", parentSprite, true);
                    temp && tempData.UICompontents.push(temp);
                }
                //遍历所有子节点
                await getChildsSprite(node, data, node);
                await getChildsSprite(node, tempData, node, true);

                //判断json是否已存在，如果存在，则修改文件名
                let jsonPath = `${outPath}/${node.name.value}.json`;
                fs.access(jsonPath, err => {
                    if (!err) {
                        fs.renameSync(jsonPath, `${outPath}/${node.name.value}_${Date.now()}.json`)
                    }
                    fs.appendFileSync(jsonPath, JSON.stringify(data));

                    let jsonPathTemp = `${outPath}/${node.name.value}_Editor.json`;
                    fs.access(jsonPathTemp, err => {
                        if (!err) {
                            fs.renameSync(jsonPathTemp, `${outPath}/${node.name.value}_${Date.now()}.json`)
                        }
                        fs.appendFileSync(jsonPathTemp, JSON.stringify(tempData));
                        console.log("JSON文件生成完成");
                    });
                });
            }
        }
    },
    async unloadAllRes() {
        console.time("卸载完成");
        const type = Editor.Selection.getLastSelectedType();
        if (type && type === "node") {
            const uuid = Editor.Selection.getLastSelected(type);
            const node = await getNode(uuid);
            if (node) {

                //判断配置文件是否存在
                let jsonPath = `${outPath}/${node.name.value}.json`;
                fs.access(jsonPath, async (err) => {
                    if (err) {
                        console.error("JSON文件不存在。");
                        return;
                    }
                    let childers = [];
                    await getAllChilders(node, childers);
                    childers.push(node);
                    if (childers) {
                        childers.forEach(childer => {
                            setSpriteFrame(childer, "");
                        });
                    }
                });

            }
            console.timeEnd("卸载完成");
        }
    },
    async loadAllRes() {
        console.time("加载完成");
        const type = Editor.Selection.getLastSelectedType();
        if (type && type === "node") {
            const uuid = Editor.Selection.getLastSelected(type);
            let isDefault = await isCocosRes(uuid);
            if (isDefault) return;
            const node = await getNode(uuid);
            if (node) {
                //判断JSON文件是否存在
                let jsonPath = `${outPath}/${node.name.value}_Editor.json`;
                fs.readFile(jsonPath, "utf-8",async (err, data) => {
                    if (err) {
                        console.err(`找不到 ${jsonPath}`);
                        console.timeEnd("加载完成");
                        return;
                    }
                    let jsonObj = JSON.parse(data);
                    if (jsonObj) {
                        // jsonObj.UICompontents.forEach(async (element) => {
                        //     let childer = await findChilder(node, element.path);
                        //     if (childer) {
                        //        await setSpriteFrame(childer, element.resUUID);
                        //     }
                        // });
                        for (let i = 0,len=jsonObj.UICompontents.length; i < len; i++) {
                            let element = jsonObj.UICompontents[i];
                            let childer = await findChilder(node, element.path);
                            if (childer) {
                               setSpriteFrame(childer, element.resUUID);
                            }
                        }
                    }
                    console.timeEnd("加载完成");
                });
            }
        }
    },
};

/*** 是否是引擎资源*/
const isCocosRes = async function (uuid) {
    // console.log(uuid);
    let tpath = await Editor.Message.request("asset-db", "query-path", uuid);
    // console.log(tpath);
    // console.log(tpath.indexOf(".editor"));
    if (tpath && tpath.indexOf(".editor") !== -1)//证明是引擎自带资源
        return true;
    return false;
}

const isBundle = async function(uuid){

}

/**查找子节点 */
const findChilder = async function (node, path) {
    if (node) {
        const childers = [];
        await getAllChilders(node, childers);
        childers.push(node);
        if (childers) {
            for (let i = 0; i < childers.length; i++) {
                let childer = childers[i];
                if (path === "this" && childer.uuid.value == node.uuid.value) {
                    return childer;
                } else {
                    let temp = await getNodePath(childer, node);
                    //console.log(temp, path);
                    if (temp === path) {
                        return childer;
                    }
                }

            }
        }
    }
}
/**设置精灵 */
const setSpriteFrame =async function (node, spriteFrameUUID) {
    let sprite = getComponent(node, "cc.Sprite");
    if (sprite) {

        if(sprite.value.spriteFrame.value.uuid != ""){
            // console.log(sprite.value.spriteFrame.value.uuid);
            let isDefault = await isCocosRes(sprite.value.spriteFrame.value.uuid)
            // console.log(isDefault);
            if(isDefault) return;
        }

        Editor.Message.send("scene", "set-property", {
            "uuid": node.uuid.value,
            "path": `__comps__.1.spriteFrame`,
            "dump": {
                "type": "cc.SpriteFrame",
                "value": {
                    "uuid": spriteFrameUUID
                }
            }
        });
    }
}
/**得到该节点的所有子节点 */
const getAllChilders = async function (parent, out) {
    if (parent) {
        if (parent.children && parent.children.length > 0) {
            for (let i = 0; i < parent.children.length; i++) {
                const current = parent.children[i];
                const node = await getNode(current.value.uuid);
                if (node) out.push(node);
                await getAllChilders(node, out);
            }
        }
    }
}
/**通过uuid得到节点 */
const getNode = async function (uuid) {
    if (uuid) {
        return await Editor.Message.request("scene", "query-node", uuid);
    }
}
/**得到所有子节点的Sprite组件 */
const getChildsSprite = async function (node, data, parent, isAddresUUID = false) {
    if (node) {
        if (node.children && node.children.length > 0) {
            for (let i = 0, len = node.children.length; i < len; i++) {
                const currentNode = node.children[i];
                if (!currentNode) continue;
                const current = await getNode(currentNode.value.uuid);
                const sprite = getComponent(current, "cc.Sprite");
                // if(sprite){
                const path = await getNodePath(current, parent);
                // console.log(path, sprite);
                const obj = await getCompontentsObject(path, sprite, isAddresUUID);
                // console.log(obj);

                obj && data.UICompontents.push(obj);
                // }
                // console.log(current);
                await getChildsSprite(current, data, parent, isAddresUUID);
            }
        }
    }
};
/**得到节点的相对路径 */
const getNodePath = async function (node, parent) {
    let path = node.name.value;
    let temp = await getNode(node.parent.value.uuid);
    // console.log(parent.uuid.value);
    while (temp && temp.uuid.value != parent.uuid.value) {
        // console.log(temp.uuid.value);
        path = temp.name.value + "/" + path;
        temp = await getNode(temp.parent.value.uuid);
    }
    return path;
};
/**得到组件 */
const getComponent = function (node, component) {
    if (node.__type__ === "cc.Node") {
        for (let i = 0; i < node.__comps__.length; i++) {
            const element = node.__comps__[i];
            if (element.type == component) {
                return element;
            }
        }
    }
};
/**转成json对象 */
const getCompontentsObject = async function (path, sprite, isAddresUUID = false) {
    if (!sprite || !sprite.value.spriteFrame || !sprite.value.spriteFrame.value.uuid) return null;
    // console.log(sprite.value.spriteFrame);

    let tpath = await isCocosRes(sprite.value.spriteFrame.value.uuid)
    // console.log(tpath);
    if (tpath)//证明是引擎自带资源
        return null;

    let info = await Editor.Message.request("asset-db", "query-asset-info", sprite.value.spriteFrame.value.uuid);

    // console.log(info);
    let data;
    if (isAddresUUID)
        data = {path, uiType: "Image", resName: "", resUUID: sprite.value.spriteFrame.value.uuid};
    else
        data = {path, uiType: "Image", resName: ""};

    if (info.path.includes("assets/resources/")) {
        data.bundleName = "resources";
    } else {
        let bundlePath = info.path.concat();
        let resPath = bundlePath.concat();
        // bundlePath = bundlePath.replace("db://assets/","");
        // bundlePath = bundlePath.replace("db://internal/","");
        // let bundlePaths = bundlePath.split("/");
        // bundlePaths.splice(0, 1);
        // bundlePaths.pop();
        // bundlePaths.pop();
        // let bunldeName = "";
        // for (let i = 0; i < bundlePaths.length; i++) {
        //     // let dirInfo = await Editor.Message.request("asset-db", "query-asset-info", );
        //     // let meta = await Editor.Message.request("asset-db", "query-asset-meta", );
        //     if (i == bundlePaths.length - 1)
        //         bunldeName += bundlePaths[i];
        //     else
        //         bunldeName += bundlePaths[i] + "/";
        // }

        let tempPath;
        do {
            let index = bundlePath.lastIndexOf("/");
            // console.log(index);
            // console.log(bundlePath);
            if(index){
                tempPath = bundlePath.slice(0,index);
                bundlePath = tempPath;
                let meta = await Editor.Message.request("asset-db", "query-asset-meta",tempPath);
                if(meta && meta.userData && meta.userData.isBundle){
                    //资源从bundle开始的路径
                    // console.log(resPath);
                    data.resName = resPath.replace(bundlePath,"");
                    data.resName = data.resName.replace("/spriteFrame","");
                    if(data.resName[0] === "/")
                        data.resName = data.resName.slice(1,data.resName.length);

                    let index2 = bundlePath.lastIndexOf("/");
                    data.bundleName = bundlePath.slice(index2+1,bundlePath.length);//bundle


                    tempPath=null;
                }
            }else{
                tempPath=null;
            }
        } while (tempPath);


        // data.bundleName = tempPath;
    }
    // const paths = info.path.split("/");
    // paths.pop();
    // data.resName = paths.pop();
    return data;
};

//当扩展被启动的时候执行
exports.load = function () {

};

//当扩展被关闭的时候执行
exports.unload = function () {
};


//移除resUUID(已废除)
// exports.onAssetMenu = function (assetInfo) {
//     return [
//         {
//             label: "移除resUUID",
//             click() {
//                 if (assetInfo.importer === "json") {
//                     fs.readFile(assetInfo.file, "utf-8", (err, data) => {
//                         if (err) {
//                             console.err(`找不到 ${assetInfo.file}`);
//                             return;
//                         }
//                         let jsonObj = JSON.parse(data);
//                         if (jsonObj) {
//                             jsonObj.UICompontents.forEach((element) => {
//                                 delete element.resUUID;
//                             });
//                             fs.writeFileSync(assetInfo.file, JSON.stringify(jsonObj));
//                             console.log("移除完成");
//                         }
//                     });
//                 }
//             }
//         }
//     ];
// }