'use strict';
const fs = require("fs");
const path = require("path");
const { methods } = require("../browser");

// html 文本
// exports.template = fs.readFileSync(path.join(__dirname, "../", "runoob-vue3-test/index.html"), "utf8");

exports.template = fs.readFileSync(path.join(__dirname, "/default.html"), "utf8");
// exports.template=fs.readFileSync(__dirname+"/default.html","utf8");

// exports.template = `
// <ui-curve :value="value"></ui-curve>
// <ui-button>Replace</ui-button>
// <ui-asset droppable="cc.AnimCurve" value=""></ui-asset>
// `;


// 样式文本
//<ui-curve-editor :value="keyframes"></ui-curve-editor>  cc.AnimCurve
exports.style = `
ui-asset {margin:15px 5% 5px; width:90%}
ui-button {margin:5px 5%;}
ui-curve-editor {margin:0px 0% 0px; width:500px;height:500px}
#pro {margin:15px 5%;width:90%;height:30px}
button {border-radius: 15px;}
`;
// header {color:red;font-size:30px}
// ui-input {margin: 0 auto;center; width:300px;height:30px}
// #layout_button {width:80px;height:30px}


// 渲染后 html 选择器
exports.$ = {
    material: '.mat',
    replaceBtn: '#replace',
    testBtn: "#test",
    pro: '#pro',
    app: "#app",
    canvas: "#myCanvas",
    pro2:'#pro2',
};
// 面板上的方法
exports.methods = {
    click() {
        const mat = this.$.material.value;
        if (mat && mat.length > 0) {
            Editor.Message.send("hello-world", "replace", mat);
        } else {
            console.error("没有找到材质");
        }
    },
    addLayout() {
        console.log("testbtn-click");
        if (this.$.pro.value < 100) {
            this.$.pro.value += 10;
        }
    }
};
// 面板上触发的事件
exports.listeners = {};

// 当面板渲染成功后触发
exports.ready = async function () {
    console.log("面板打开");

    let Vue = require("../vue");
    let self = this;
    let app2Obj = new Vue({
        el:"app2"
    })
    new Vue({
        el: this.$.app,
        data() {
            return {
                name: "hello",
                pro2Value:0
            };
        },
        created() {
            console.log("created");

        },
        methods: {
            onClick() {
                console.log("点击按钮");
                // let gameCanvas =  window.parent.document.getElementById("GameCanvas");
                let gameCanvas2 = window.parent.document.getElementsByClassName("gameCanvas");
                // console.log("GameCanvas1",gameCanvas);
                console.log(window.parent.document);
                console.log("GameCanvas2",gameCanvas2,gameCanvas2.height);

                

                this.name = "222";

                if(this.pro2Value<100)
                    this.pro2Value+=5;

                let ctx = self.$.canvas.getContext("2d");
                ctx.fillStyle="#d63030";
                ctx.strokeStyle="#d63030";
                // console.log(ctx);
                ctx.moveTo(0, 0);
                ctx.lineTo(200, 100);
                ctx.stroke();
            }
        },
        watch:{
            pro2Value(newValue,oldValue){
                console.log(`new:${newValue},old:${oldValue}`);
            }
        }
    });

    // console.log(path.join(__dirname, "../", "runoob-vue3-test/index.html"));
    if (this.$.testBtn) {
        this.$.testBtn.addEventListener("confirm", () => {
            console.log("testbtn-click");
            if (this.$.pro.value < 100) {
                this.$.pro.value += 10;
            }
        });
    }

    if (this.$.replaceBtn) {
        this.$.replaceBtn.addEventListener("confirm", () => {
            const mat = this.$.material.value;
            if (mat && mat.length > 0) {
                Editor.Message.send("hello-world", "replace", mat);
            } else {
                console.error("没有找到材质");
            }
        });
    }
    // console.log(this.$.pro);
    // this.$.pro.value=10;
    // const temp;
    // temp = setInterval(() => {
    //     this.$.pro.value+=10;
    //     if(this.$.pro.value>=100){
    //         clearInterval(temp);
    //     }
    // }, 500);
};
// 尝试关闭面板的时候触发
exports.beforeClose = async function () {
    console.log("面板开始关闭");
};
// 当面板实际关闭后触发
exports.close = async function () {
    console.log("面板成功关闭");
};